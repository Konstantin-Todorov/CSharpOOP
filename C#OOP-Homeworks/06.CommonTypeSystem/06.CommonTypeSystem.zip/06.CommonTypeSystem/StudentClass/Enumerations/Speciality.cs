﻿
namespace StudentClass.Enumerations
{
    public enum Speciality
    {
        Menagement, Physiology, MehanicalEngineering 
    }
}
