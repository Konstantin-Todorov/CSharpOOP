﻿
namespace StudentClass.Enumerations
{
    public enum University
    {
        SofiaUniversity , NBU , AngelKunchev , ChernorizecHrabur 
    }
}
