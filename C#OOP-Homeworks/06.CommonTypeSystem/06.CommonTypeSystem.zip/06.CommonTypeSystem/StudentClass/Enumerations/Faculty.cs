﻿
namespace StudentClass.Enumerations
{
    public enum Faculty
    {
        Ecology, Informatics, Physiology, Phiology, Agronomy, Engeneering
    }
}
