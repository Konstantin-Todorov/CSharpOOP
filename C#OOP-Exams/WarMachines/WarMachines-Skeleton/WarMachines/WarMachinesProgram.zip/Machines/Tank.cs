﻿namespace WarMachines.Machines
{
    using Interfaces;
    using System.Text;

    public class Tank : Machine , ITank
    {
        public Tank(string name, double attackPoints, double defensePoints, IPilot pilot = null)
            : base(name, 100, attackPoints, defensePoints, pilot)
        {
            this.ToggleDefenseMode();
        }

        public bool DefenseMode { get; protected set; }

        public void ToggleDefenseMode()
        {
            if (!this.DefenseMode)
            {
                base.DefensePoints += 30;
                base.AttackPoints -= 40;
                this.DefenseMode = true;
            }
            else
            {
                base.DefensePoints -= 30;
                base.AttackPoints += 40;
                this.DefenseMode = false;
            }
        }

        public override string ToString()
        {
            StringBuilder result = new StringBuilder(base.ToString());
            result.AppendFormat(" *Defence: {0}", this.DefenseMode ? "ON" : "OFF");

            return result.ToString().Trim();
        }
    }
}
