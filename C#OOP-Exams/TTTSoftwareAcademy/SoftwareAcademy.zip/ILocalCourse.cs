﻿namespace SoftwareAcademy
{
    public interface ILocalCourse : ICourse
    {
        string Lab { get; set; }
    }
}
