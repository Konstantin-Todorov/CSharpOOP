﻿namespace Infestation
{
    public class Queen : InfestUnit
    {
        public Queen(string id)
            :base(id,UnitClassification.Biological,1,1,1)
        {

        }
    }
}
