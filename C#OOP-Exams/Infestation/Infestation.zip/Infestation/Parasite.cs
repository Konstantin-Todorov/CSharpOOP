﻿namespace Infestation
{
    public class Parasite : InfestUnit
    {
        public Parasite(string id)
            :base(id,UnitClassification.Psionic,30,1,1)
        {

        }
    }
}
